package com.sts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sts.entity.Department;
import com.sts.service.DepartmentServiceImpl;

@RestController
@RequestMapping("/department")
public class DepartmentController {

	@Autowired
	DepartmentServiceImpl departmentService;
	@GetMapping("/home")
	@ResponseBody
	public String home() {
		
		return "hello testme";
	}
	
	@PostMapping("/")
	public Department saveDepartment(@RequestBody Department department) {
		
		return departmentService.saveDepartment(department);
	}
	
	@GetMapping("/")
	public List<Department> getDepartmentList() {
		
		return departmentService.getDepartmentList();
	}
	
	@GetMapping("/{id}")
	public Department getDepartmentById(@PathVariable("id") Long id) {
		
		return departmentService.getDepartmentList(id);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<HttpStatus> deleteDepartmentById(@PathVariable("id") Long id) {
		try {
			departmentService.deleteDepartmentById(id);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch(Exception e) {
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);	
		}
	}
	
	@PutMapping("/{id}")
	public Department updateDepartment(@PathVariable("id") Long id,@RequestBody Department department) {
		
		return departmentService.updateDepartment(id,department);
	}
}
