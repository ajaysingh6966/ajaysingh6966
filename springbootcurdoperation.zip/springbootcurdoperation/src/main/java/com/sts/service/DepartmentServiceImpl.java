package com.sts.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sts.entity.Department;
import com.sts.repository.IDepartmentRepository;


@Service
public class DepartmentServiceImpl implements IDepartmentService {

	@Autowired
	IDepartmentRepository departmentRepository;
	
	@Override
	public Department saveDepartment(Department department) {
		return departmentRepository.save(department);
	}

	public List<Department> getDepartmentList() {
		return departmentRepository.findAll();
	}

	public Department getDepartmentList(Long id) {
		Optional<Department> departmentOpt = departmentRepository.findById(id);
		
		return departmentOpt.get();
	}

	public void deleteDepartmentById(Long id) {
		departmentRepository.deleteById(id);
	}

	public Department updateDepartment(Long id,Department department) {
		Department dbDepartment=departmentRepository.findById(id).get();
		
		if (department != null && Objects.nonNull(department.getDepartmentName())
				&& !"".equalsIgnoreCase(department.getDepartmentName())) {
			dbDepartment.setDepartmentName(department.getDepartmentName());
		}
		if (department != null && Objects.nonNull(department.getDepartmentAddress())
				&& !"".equalsIgnoreCase(department.getDepartmentAddress())) {
			dbDepartment.setDepartmentAddress(department.getDepartmentAddress());
		}
		if (department != null && Objects.nonNull(department.getDepartmentCode())
				&& !"".equalsIgnoreCase(department.getDepartmentCode())) {
			dbDepartment.setDepartmentCode(department.getDepartmentCode());
		}
		return departmentRepository.save(dbDepartment);
	}

	
	

}
