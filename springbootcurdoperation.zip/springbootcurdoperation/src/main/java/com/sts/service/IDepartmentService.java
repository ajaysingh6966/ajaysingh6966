package com.sts.service;

import java.util.List;

import com.sts.entity.Department;

public interface IDepartmentService {

	public Department saveDepartment(Department department);
	public List<Department> getDepartmentList();
	public Department getDepartmentList(Long id);
	public void deleteDepartmentById(Long id);
	public Department updateDepartment(Long id,Department department);
}
